--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

DROP INDEX public.idx_results_location;
ALTER TABLE ONLY public.results DROP CONSTRAINT results_pkey;
ALTER TABLE ONLY public.district_statistics DROP CONSTRAINT district_statistics_pkey;
ALTER TABLE ONLY public.block_statistics DROP CONSTRAINT block_statistics_pkey;
ALTER TABLE public.results ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.district_statistics ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.block_statistics ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.results_id_seq;
DROP TABLE public.results;
DROP SEQUENCE public.district_statistics_id_seq;
DROP TABLE public.district_statistics;
DROP SEQUENCE public.block_statistics_id_seq;
DROP TABLE public.block_statistics;
SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: block_statistics; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE block_statistics (
    id integer NOT NULL,
    join_key character varying,
    time_step timestamp without time zone,
    isp character varying,
    sumrtt bigint,
    countrtt integer,
    rtt_samples double precision[],
    download_count integer,
    download_octets bigint,
    download_time double precision,
    download_samples double precision[],
    upload_count integer,
    upload_octets bigint,
    upload_time double precision,
    upload_samples double precision[]
);


ALTER TABLE block_statistics OWNER TO postgres;

--
-- Name: block_statistics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE block_statistics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE block_statistics_id_seq OWNER TO postgres;

--
-- Name: block_statistics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE block_statistics_id_seq OWNED BY block_statistics.id;


--
-- Name: district_statistics; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE district_statistics (
    id integer NOT NULL,
    join_key integer,
    time_step timestamp without time zone,
    isp character varying,
    sumrtt bigint,
    countrtt integer,
    rtt_samples double precision[],
    download_count integer,
    download_octets bigint,
    download_time double precision,
    download_samples double precision[],
    upload_count integer,
    upload_octets bigint,
    upload_time double precision,
    upload_samples double precision[]
);


ALTER TABLE district_statistics OWNER TO postgres;

--
-- Name: district_statistics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE district_statistics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE district_statistics_id_seq OWNER TO postgres;

--
-- Name: district_statistics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE district_statistics_id_seq OWNED BY district_statistics.id;


--
-- Name: results; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE results (
    id bigint NOT NULL,
    "time" timestamp without time zone,
    location geometry(Point,4326),
    client_ip bigint,
    server_ip bigint,
    countrtt bigint,
    sumrtt bigint,
    download_flag boolean,
    download_time bigint,
    download_octets bigint,
    upload_time bigint,
    upload_octets bigint,
    bigquery_key character varying
);


ALTER TABLE results OWNER TO postgres;

--
-- Name: results_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE results_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE results_id_seq OWNER TO postgres;

--
-- Name: results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE results_id_seq OWNED BY results.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY block_statistics ALTER COLUMN id SET DEFAULT nextval('block_statistics_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY district_statistics ALTER COLUMN id SET DEFAULT nextval('district_statistics_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY results ALTER COLUMN id SET DEFAULT nextval('results_id_seq'::regclass);


--
-- Data for Name: block_statistics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY block_statistics (id, join_key, time_step, isp, sumrtt, countrtt, rtt_samples, download_count, download_octets, download_time, download_samples, upload_count, upload_octets, upload_time, upload_samples) FROM stdin;
\.
COPY block_statistics (id, join_key, time_step, isp, sumrtt, countrtt, rtt_samples, download_count, download_octets, download_time, download_samples, upload_count, upload_octets, upload_time, upload_samples) FROM '$$PATH$$/3470.dat';

--
-- Name: block_statistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('block_statistics_id_seq', 2223, true);


--
-- Data for Name: district_statistics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY district_statistics (id, join_key, time_step, isp, sumrtt, countrtt, rtt_samples, download_count, download_octets, download_time, download_samples, upload_count, upload_octets, upload_time, upload_samples) FROM stdin;
\.
COPY district_statistics (id, join_key, time_step, isp, sumrtt, countrtt, rtt_samples, download_count, download_octets, download_time, download_samples, upload_count, upload_octets, upload_time, upload_samples) FROM '$$PATH$$/3472.dat';

--
-- Name: district_statistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('district_statistics_id_seq', 1289, true);


--
-- Data for Name: results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY results (id, "time", location, client_ip, server_ip, countrtt, sumrtt, download_flag, download_time, download_octets, upload_time, upload_octets, bigquery_key) FROM stdin;
\.
COPY results (id, "time", location, client_ip, server_ip, countrtt, sumrtt, download_flag, download_time, download_octets, upload_time, upload_octets, bigquery_key) FROM '$$PATH$$/3474.dat';

--
-- Name: results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('results_id_seq', 257974, true);


--
-- Name: block_statistics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY block_statistics
    ADD CONSTRAINT block_statistics_pkey PRIMARY KEY (id);


--
-- Name: district_statistics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY district_statistics
    ADD CONSTRAINT district_statistics_pkey PRIMARY KEY (id);


--
-- Name: results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY results
    ADD CONSTRAINT results_pkey PRIMARY KEY (id);


--
-- Name: idx_results_location; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX idx_results_location ON results USING gist (location);


--
-- PostgreSQL database dump complete
--

